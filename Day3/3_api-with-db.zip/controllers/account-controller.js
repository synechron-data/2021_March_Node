exports.isAuthenticated = function (req, res, next) {
    // Logic to Check User Authentication Status
    if (req.isAuthenticated())
        next();
    else
        res.redirect('/account');

    // res.status(401).send("Unauthorized Access!");
}

exports.login_get = function (req, res, next) {
    res.render('account/login', { title: 'Login', message: req.flash('loginMessage') });
}

exports.login_post = function (passport) {
    // Logic to Authenticate the user & Redirect

    return passport.authenticate('local-login', {
        successRedirect: '/users',
        failureRedirect: '/account',
        failureFlash: true
    });
}