var express = require('express');
var router = express.Router();
var cors = require('cors');

const usersApiCtrl = require('../controllers/users-api-controller');

router.use(cors());

router.get('/', usersApiCtrl.getUsers);

module.exports = router;
