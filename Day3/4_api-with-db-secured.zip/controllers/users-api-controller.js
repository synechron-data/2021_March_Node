const da = require('../data-access');
const User = require('../models/user');

exports.getUsers = function (req, res, next) {
    da.getAllUsers().then(result => {
        res.json({ data: result, message: "Success, Getting Users" });
    }, eMsg => {
        res.status(500).json({ data: [], message: "Error, Getting Users" });
    });
}

exports.getUser = function (req, res, next) {
    da.getUser(req.params.userid).then(result => {
        res.json({ data: result, message: "Success, Getting User" });
    }, eMsg => {
        res.status(500).json({ data: null, message: "Error, Getting User" });
    });
}

exports.createUser = function (req, res, next) {
    var user = new User(req.body.username, req.body.email);

    da.insertUser(user).then(result => {
        res.json({ data: result, message: "Success, Inserting User" });
    }, eMsg => {
        res.status(500).json({ data: null, message: "Error, Inserting User" });
    });
}

exports.updateUser = function (req, res, next) {
    var user = new User(req.body.username, req.body.email);

    da.updateUser(req.params.userid, user).then(result => {
        res.json({ data: result, message: "Success, Updating User" });
    }, eMsg => {
        res.status(500).json({ data: null, message: "Error, Updating User" });
    });
}

exports.deleteUser = function (req, res, next) {
    da.deleteUser(req.params.userid).then(result => {
        res.json({ data: null, message: result });
    }, eMsg => {
        res.status(500).json({ data: null, message: "Error, Deleting User" });
    });
}