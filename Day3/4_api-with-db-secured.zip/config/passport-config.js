const LocalStrategy = require('passport-local').Strategy;

module.exports = function (passport) {
    passport.serializeUser(function (user, done) {
        done(null, user);
    });

    passport.deserializeUser(function (user, done) {
        done(null, user);
    });

    passport.use('local-login', new LocalStrategy({
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    }, function (req, email, password, done) {
        // Code to Read Username and Password from a database or a file
        
        if (email != "manish@abc.com")
            return done(null, false, req.flash('loginMessage', 'User not Found!'));

        if (password != "manish")
            return done(null, false, req.flash('loginMessage', 'Wrong Password!'));

        var user = { email, password };

        return done(null, user);
    }));
};

// The user we provide as the second argument of the done function is saved in the 
// session and is later used to retrieve the whole object via the deserializeUser function.

// serializeUser determines which data of the user object should be stored in the session. 
// The result of the serializeUser method is attached to the session as req.session.passport.user = {}.