var express = require('express');
var router = express.Router();
var cors = require('cors');

const accountCtrl = require('../controllers/account-controller');
const usersApiCtrl = require('../controllers/users-api-controller');

router.use(cors());

router.use(accountCtrl.validateToken);

// GET - /api/users (Get All users)
router.get('/', usersApiCtrl.getUsers);

// GET - /api/users/:userid  (Get single user by id)
router.get('/:userid', usersApiCtrl.getUser);

// POST - /api/users (Create an user)
router.post('/', usersApiCtrl.createUser);

// PUT - /api/users/:userid  (Update an user)
router.put('/:userid', usersApiCtrl.updateUser);

// DELETE - /api/users/:userid   (Delete an user)
router.delete('/:userid', usersApiCtrl.deleteUser);

module.exports = router;

