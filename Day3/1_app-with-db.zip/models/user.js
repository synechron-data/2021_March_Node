class User {
    constructor(uname, uemail) {
        this.username = uname;
        this.email = uemail;
    }
}

module.exports = User;

// let mongoose = require('mongoose');
// let validator = require('validator');

// let userSchema = new mongoose.Schema({
//     username: String,
//     email: {
//         type: String,
//         required: true,
//         unique: true,
//         validate: (value)=>{
//             return validator.isEmail(value)
//         }
//     }
// });

// module.exports = mongoose.model('User', userSchema);