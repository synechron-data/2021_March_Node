var express = require('express');
const { body, validationResult } = require('express-validator');

var router = express.Router();

const accCtrl = require('../controllers/account-controller');
const usersCtrl = require('../controllers/users-controller');

router.use(accCtrl.isAuthenticated);

router.get('/', usersCtrl.index);

router.get('/details/:userid', usersCtrl.details);

router.get('/create', usersCtrl.create_get);

router.post('/create', body('email').isEmail(), usersCtrl.create_post);

router.get('/edit/:userid', usersCtrl.edit_get);

router.post('/edit/:userid', usersCtrl.edit_post);

router.get('/delete/:userid', usersCtrl.delete_get);

router.post('/delete/:userid', usersCtrl.delete_post);

module.exports = router;
