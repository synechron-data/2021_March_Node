// console.log(require('repl')._builtinLibs);

const readline = require('readline');
// console.log(readline);

const rl = readline.createInterface({
    input: process.stdin,       // ReadStream
    output: process.stdout      // WriteStream    
});

// rl.question("Enter a number: ", (input) => {
//     console.log(`You entered ${input}`);
//     rl.close();
// });

// console.log("\n-------------------------- Last Line --------------------------\n");

// rl.question("Enter the first number: ", (input1) => {
//     rl.question("Enter the second number: ", (input2) => {
//         var sum = parseInt(input1) + parseInt(input2);
//         console.log(`Result is ${sum}`);
//         rl.close();
//     });
// });

// ---------------------------------------------------- Using Promise

function enterNumberOne() {
    return new Promise((resolve) => {
        rl.question("Enter the first number: ", (input) => {
            var num = parseInt(input);
            resolve(num);
        });
    });
}

function enterNumberTwo(n1) {
    return new Promise((resolve) => {
        rl.question("Enter the second number: ", (input) => {
            var num = parseInt(input);
            resolve([n1, num]);
        });
    });
}

function add([n1, n2]) {
    var sum = n1 + n2;
    console.log(`Result is: ${sum}`);
    rl.close();
}

enterNumberOne().then(enterNumberTwo).then(add);