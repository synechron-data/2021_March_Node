// Every action which you perform on your computer system is an event

// var events = require('events');
// var eEmitter = new events.EventEmitter();

// // Subscribe
// eEmitter.addListener('test', ()=>{
//     console.log("Listener is executed...");
// });

// eEmitter.emit('test');          // Publish

// ----------------------------------

const StringEmitter = require('./StringEmitter');
const sEmitter = new StringEmitter();

// var s = sEmitter.getString();
// console.log(s);

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// sEmitter.pushString((s) => {
//     console.log(s);
// });

sEmitter.on('data', (s) => {
    console.log("S1 - ", s);
});

let count = 0;
function S2(s) {
    ++count;
    console.log("S2 - ", s.toUpperCase());
    if (count > 2) {
        sEmitter.removeListener('data', S2);
    }
}

sEmitter.on('data', S2);