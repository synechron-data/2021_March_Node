// require('./lib.js');        // Load and Cache the Module

// const lib = require('./lib.js');
// console.log(lib);
// console.log(lib.firstname);
// console.log(lib.lastname);
// console.log(lib.log("Hello from App Module"));

// const lib = require('./lib.js');
// let e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const { Employee } = require('./lib.js');
// let e1 = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// -----------------------------------------------
//  The Module is Loaded once and Cached for future require
// const lib1 = require('./lib.js');
// const lib2 = require('./lib.js');

// console.log(lib1 === lib2);

// -----------------------------------------------
// const lib = require('./lib');
// console.log(lib);

// const logger = require('./logger');

// -----------------------------------------------
// const loggerService = require('./loggerService');
// loggerService.log("Hi from App Module");

// const loggerSingle = require('./loggerSingle');

// let l1 = loggerSingle.getLogger();
// l1.log("Hello from App Module");

// let l2 = loggerSingle.getLogger();
// l2.log("Hello from App Module");

// console.log(l1 === l2);

// ----------------------------------------------- Assignment

const loggerFactory = require('./loggerFactory');

let dbLogger = loggerFactory.DBLFactory.getLogger();
let flLogger = loggerFactory.FLFactory.getLogger();

dbLogger.log("Hello from App Module");
flLogger.log("Hello from App Module");

let dbLogger1 = loggerFactory.DBLFactory.getLogger();
let dbLogger2 = loggerFactory.DBLFactory.getLogger();

console.log(dbLogger1 === dbLogger2);